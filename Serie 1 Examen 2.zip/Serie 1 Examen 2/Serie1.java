import java.util.ArrayList;
import java.util.List;

class TreeNode {
    int val; // Valor del nodo
    TreeNode left; // Hijo izquierdo
    TreeNode right; // Hijo derecho
    TreeNode(int x) { val = x; }
}

public class Serie1 {

    public List<List<Integer>> pathSum(TreeNode root, int targetSum) {
        List<List<Integer>> result = new ArrayList<>(); // Lista que almacenará los caminos válidos
        findPaths(root, targetSum, new ArrayList<>(), result); // Inicia la búsqueda de caminos
        return result;
    }

    private void findPaths(TreeNode node, int sum, List<Integer> path, List<List<Integer>> result) {
        if (node == null) return;

        path.add(node.val);
        sum -= node.val;

        if (node.left == null && node.right == null && sum == 0) {
            result.add(new ArrayList<>(path));
        } else {
            findPaths(node.left, sum, path, result);
            findPaths(node.right, sum, path, result);
        }

        path.remove(path.size() - 1);
    }

    public static void main(String[] args) {
        // Arbol binario
        TreeNode root = new TreeNode(5);
        root.left = new TreeNode(4);
        root.right = new TreeNode(8);
        root.left.left = new TreeNode(11);
        root.left.left.left = new TreeNode(7);
        root.left.left.right = new TreeNode(2);
        root.right.left = new TreeNode(13);
        root.right.right = new TreeNode(4);
        root.right.right.right = new TreeNode(1);


        // Se crea una instancia de la clase y se llama al método pathSum
        Serie1 finder = new Serie1();
        List<List<Integer>> paths = finder.pathSum(root, 22);

        System.out.println("Caminos con suma 22:");
        for (List<Integer> path : paths) {
            System.out.println(path);
        }
    }
}
