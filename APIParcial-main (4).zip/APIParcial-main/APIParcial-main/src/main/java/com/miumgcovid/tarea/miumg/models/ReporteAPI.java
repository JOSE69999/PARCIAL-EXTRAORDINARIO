package com.miumgcovid.tarea.miumg.models;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "reportes")
@IdClass(ReporteId.class)
public class ReporteAPI {

    @Id
    private String date;

    @Id
    private String iso;


    private String regionIso;
    private String province;
    private int confirmed;
    private int deaths;
    private int recovered;

    // Getters y Setters
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getIso() { return iso; }
    public void setIso(String iso) { this.iso = iso; }

    public String getRegionIso() { return regionIso; }
    public void setRegionIso(String regionIso) { this.regionIso = regionIso; }

    public String getProvince() { return province; }
    public void setProvince(String province) { this.province = province; }

    public int getConfirmed() { return confirmed; }
    public void setConfirmed(int confirmed) { this.confirmed = confirmed; }

    public int getDeaths() { return deaths; }
    public void setDeaths(int deaths) { this.deaths = deaths; }

    public int getRecovered() { return recovered; }
    public void setRecovered(int recovered) { this.recovered = recovered; }
}