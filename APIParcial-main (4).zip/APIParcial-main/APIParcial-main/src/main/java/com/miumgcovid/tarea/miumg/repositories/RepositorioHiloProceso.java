package com.miumgcovid.tarea.miumg.repositories;

import com.miumgcovid.tarea.miumg.models.ExecutedReport;
import com.miumgcovid.tarea.miumg.services.ServicioPeticion;
import com.miumgcovid.tarea.miumg.repositories.ExecutedReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public class RepositorioHiloProceso implements Runnable{

    @Value("${api.delay.seconds}")
    private int delayHilo;

    @Value("${covid.report.date}")
    private String reportDate;

    @Autowired
    private ServicioPeticion servicio;

    @Autowired
    private ExecutedReportRepository executedRepo;

    public void iniciarHilo() {
        Thread hilo = new Thread(this);
        hilo.start();
    }

    @Override
    public void run() {
        try {
            Thread.sleep(delayHilo * 1000L);
            String iso = "GTM"; // Cambia según el país que quieras procesar
            LocalDate date = LocalDate.parse(reportDate);

            // Verifica si ya se ejecutó
            if (executedRepo.existsByIsoAndExecutionDate(iso, date)) {
                System.out.println("✅ País " + iso + " ya fue procesado el " + date);
                return;
            }

            // Ejecuta si no ha sido procesado
            servicio.buscaRegiones();
            servicio.buscaProvincias();
            servicio.buscaReporte();

            // Registra la ejecución
            ExecutedReport registro = new ExecutedReport();
            registro.setIso(iso);
            registro.setExecutionDate(date);
            executedRepo.save(registro);

            System.out.println("✅ País " + iso + " procesado y registrado el " + date);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
