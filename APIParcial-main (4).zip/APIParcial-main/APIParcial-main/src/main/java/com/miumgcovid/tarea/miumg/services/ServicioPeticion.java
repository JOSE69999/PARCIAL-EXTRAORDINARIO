package com.miumgcovid.tarea.miumg.services;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.miumgcovid.tarea.miumg.repositories.RepositorioReporte;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.miumgcovid.tarea.miumg.models.RegionAPI;
import com.miumgcovid.tarea.miumg.models.ProvinciaAPI;
import com.miumgcovid.tarea.miumg.models.ReporteAPI;
import com.miumgcovid.tarea.miumg.repositories.repositorioRegion;
import com.miumgcovid.tarea.miumg.repositories.RepositorioProvincia;

import java.util.stream.Collectors;
import java.util.TreeMap;

@Service
public class ServicioPeticion {

    // URLs de las APIs
    final String regionesURL = "https://covid-19-statistics.p.rapidapi.com/regions";
    final String provinciasURL = "https://covid-19-statistics.p.rapidapi.com/provinces";
    final String reporteURL = "https://covid-19-statistics.p.rapidapi.com/reports?iso=GTM&date=2022-04-16";

    // Instancia RestTemplate
    final RestTemplate request = new RestTemplate();
    private HttpHeaders header = new HttpHeaders();

    // Inyección de dependencias para los repositorios
    @Autowired
    private repositorioRegion repositorioRegion;

    @Autowired
    private RepositorioProvincia repositorioProvincia;

    @Autowired
    private RepositorioReporte repositorioReporte;

    public void guardaReporte(ReporteAPI reporte) {
        // Verifica si ya existe un reporte con la misma fecha y iso
        if (!repositorioReporte.existsByDateAndIso(reporte.getDate(), reporte.getIso())) {
            // Si no existe, guarda el reporte en la base de datos
            repositorioReporte.save(reporte);
            System.out.println("Reporte guardado: " + reporte.getDate() + " - " + reporte.getIso());
        } else {
            // Si ya existe, no lo guarda
            System.out.println("Reporte ya existe: " + reporte.getDate() + " - " + reporte.getIso());
        }
    }
    public List<ReporteAPI> obtenerReportesUnicosPorProvincia(String iso, String date) {
        // Obtener los reportes por ISO y fecha
        List<ReporteAPI> reportes = repositorioReporte.findByIsoAndDate(iso, date);

        // Filtrar los reportes únicos por provincia
        return reportes.stream()
                .distinct() // Esto elimina duplicados
                .collect(Collectors.toList());
    }


    public List<ReporteAPI> obtenerReportesPorIsoYFecha(String iso, String date) {

        return repositorioReporte.findByIsoAndDate(iso, date);
    }

    // Constructor por defecto
    public ServicioPeticion() {
    }

    // Método para obtener las regiones
    public void buscaRegiones() {

        this.header.setContentType(MediaType.APPLICATION_JSON);
        this.header.set("X-RapidAPI-Key", "2505eda46amshc60713983b5e807p1da25ajsn36febcbf4a71");
        this.header.set("X-RapidAPI-Host", "covid-19-statistics.p.rapidapi.com");

        // Crear la entidad con la cabecera
        HttpEntity<Void> requestEntity = new HttpEntity<>(this.header);

        // Hacer la petición a la API
        ResponseEntity<String> response = this.request.exchange(this.regionesURL, HttpMethod.GET, requestEntity, String.class);

        // Convertir el cuerpo de la respuesta a un JSON
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> responseMap = mapper.readValue(response.getBody(), new TypeReference<Map<String, Object>>() {});


            Object data = responseMap.get("data");

            // Verificar que 'data' sea una lista
            if (data instanceof List<?>) {
                List<?> arrayData = (List<?>) data;
                // Verificar que los elementos sean del tipo esperado
                if (!arrayData.isEmpty() && arrayData.get(0) instanceof Map<?, ?>) {
                    List<Map<String, Object>> regionsList = (List<Map<String, Object>>) arrayData;

                    // Guardar cada región en la base de datos
                    for (Map<String, Object> dato : regionsList) {
                        String iso = (String) dato.get("iso");
                        String name = (String) dato.get("name");

                        if (iso != null && !iso.isBlank()) {
                            RegionAPI region = new RegionAPI();
                            region.setIso(iso);
                            region.setName(name != null ? name : "");
                            repositorioRegion.save(region);
                        } else {
                            System.out.println("Se encontró una región con ISO vacío o nulo. No se guardará: " + dato);
                        }
                    }
                } else {
                    System.out.println("Los datos no tienen el formato esperado.");
                }
            } else {
                System.out.println("El tipo de 'data' no es una lista.");
            }

        } catch (JsonProcessingException e) {
            System.err.println("Error al procesar el JSON: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Ocurrió un error: " + e.getMessage());
        }
    }

    // Método para obtener las provincias
    public void buscaProvincias() {

        String URLFinal = this.provinciasURL + "?iso=GTM";


        this.header = new HttpHeaders();
        this.header.setContentType(MediaType.APPLICATION_JSON);
        this.header.set("X-RapidAPI-Key", "2505eda46amshc60713983b5e807p1da25ajsn36febcbf4a71");
        this.header.set("X-RapidAPI-Host", "covid-19-statistics.p.rapidapi.com");


        Map<String, Object> data = new HashMap<>();
        data.put("iso", "GTM");
        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(data, this.header);

        // Hacer la petición a la API
        ResponseEntity<String> response = this.request.exchange(URLFinal, HttpMethod.GET, requestEntity, String.class);

        // Convertir el cuerpo de la respuesta a un JSON
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> responseMap = mapper.readValue(response.getBody(), new TypeReference<Map<String, Object>>() {});

            // Obtener la lista de provincias
            Object dataProv = responseMap.get("data");


            // Verificar que 'data' sea una lista antes de hacer el cast
            if (dataProv instanceof List<?>) {
                List<?> arrayData = (List<?>) dataProv;
                // Verificar que los elementos sean del tipo esperado
                if (!arrayData.isEmpty() && arrayData.get(0) instanceof Map<?, ?>) {
                    List<Map<String, Object>> provincesList = (List<Map<String, Object>>) arrayData;

                    // Guardar cada provincia en la base de datos
                    for (Map<String, Object> dato : provincesList) {
                        String iso = (String) dato.get("iso");
                        String name = (String) dato.get("name");

                        if (iso != null && !iso.isBlank()) {
                            // 🔽 Normalizar ISO y nombre (elimina espacios y pone mayúsculas para ISO)
                            iso = iso.trim().toUpperCase();
                            name = (name != null) ? name.trim() : "";

                            if (!repositorioProvincia.existsByIsoAndName(iso, name)) {
                                ProvinciaAPI provincia = new ProvinciaAPI();
                                provincia.setIso(iso);
                                provincia.setName(name != null ? name : "");
                                repositorioProvincia.save(provincia);
                            }
                        } else {
                            System.out.println("Se encontró una provincia con ISO vacío o nulo. No se guardará: " + dato);
                        }
                    }
                } else {
                    System.out.println("Los datos no tienen el formato esperado.");
                }
            } else {
                System.out.println("El tipo de 'data' no es una lista.");
            }

        } catch (JsonProcessingException e) {
            System.err.println("Error al procesar el JSON: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Ocurrió un error: " + e.getMessage());
        }
    }

    // Método para obtener el reporte
    public void buscaReporte() {

        // Establecer las cabeceras de la solicitud
        this.header.setContentType(MediaType.APPLICATION_JSON);
        this.header.set("X-RapidAPI-Key", "2505eda46amshc60713983b5e807p1da25ajsn36febcbf4a71");
        this.header.set("X-RapidAPI-Host", "covid-19-statistics.p.rapidapi.com");

        // Crear la entidad de solicitud con las cabeceras
        HttpEntity<Void> requestEntity = new HttpEntity<>(this.header);

        // Realizar la solicitud a la API
        ResponseEntity<String> response = this.request.exchange(this.reporteURL, HttpMethod.GET, requestEntity, String.class);

        // Procesar la respuesta
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> responseMap = mapper.readValue(response.getBody(), new TypeReference<Map<String, Object>>() {});
            Object dataReport = responseMap.get("data");

            // Verificar que 'data' es una lista
            if (dataReport instanceof List<?>) {
                List<?> arrayData = (List<?>) dataReport;

                // Verificar que los datos tengan el formato esperado
                if (!arrayData.isEmpty() && arrayData.get(0) instanceof Map<?, ?>) {
                    List<Map<String, Object>> reportList = (List<Map<String, Object>>) arrayData;

                    // Iterar sobre cada elemento del reporte
                    for (Map<String, Object> dato : reportList) {
                        String date = (String) dato.get("date");

                        // Extraer el objeto 'region' de la respuesta
                        Map<String, Object> regionMap = (Map<String, Object>) dato.get("region");

                        // Obtener los valores de 'iso', 'region' y 'province'
                        String iso = regionMap != null ? (String) regionMap.get("iso") : null;
                        String region = regionMap != null ? (String) regionMap.get("name") : null;
                        String province = regionMap != null ? (String) regionMap.get("province") : null;

                        // Obtener los valores de 'confirmed', 'deaths', y 'recovered'
                        int confirmed = dato.get("confirmed") instanceof Number ? ((Number) dato.get("confirmed")).intValue() : 0;
                        int deaths = dato.get("deaths") instanceof Number ? ((Number) dato.get("deaths")).intValue() : 0;
                        int recovered = dato.get("recovered") instanceof Number ? ((Number) dato.get("recovered")).intValue() : 0;

                        // Validar que 'date' y 'iso' no sean nulos
                        if (date != null && iso != null) {
                            // Crear una instancia de ReporteAPI
                            ReporteAPI reporte = new ReporteAPI();
                            reporte.setDate(date);
                            reporte.setIso(iso);
                            reporte.setRegionIso(region); // Asignar 'regionIso'
                            reporte.setProvince(province); // Asignar 'province'
                            reporte.setConfirmed(confirmed);
                            reporte.setDeaths(deaths);
                            reporte.setRecovered(recovered);

                            // Guardar el reporte en la base de datos
                            guardaReporte(reporte);
                        } else {
                            System.out.println("Reporte omitido por falta de fecha o iso: " + dato);
                        }
                    }
                } else {
                    System.out.println("Los datos no tienen el formato esperado.");
                }
            } else {
                System.out.println("El tipo de 'data' no es una lista.");
            }

        } catch (JsonProcessingException e) {
            System.err.println("Error al procesar el JSON: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Ocurrió un error general: " + e.getMessage());
        }
    }
}

