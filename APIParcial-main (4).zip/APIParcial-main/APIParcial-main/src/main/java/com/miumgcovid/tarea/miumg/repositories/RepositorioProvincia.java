package com.miumgcovid.tarea.miumg.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.miumgcovid.tarea.miumg.models.ProvinciaAPI;

@Repository
public interface RepositorioProvincia extends JpaRepository<ProvinciaAPI, Long> {
    boolean existsByIsoAndName(String iso, String name);
}
