package com.miumgcovid.tarea.miumg.repositories;

import com.miumgcovid.tarea.miumg.models.ExecutedReport;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;

public interface ExecutedReportRepository extends JpaRepository<ExecutedReport, Long> {
    boolean existsByIsoAndExecutionDate(String iso, LocalDate executionDate);
}
