package com.miumgcovid.tarea.miumg.models;

import java.io.Serializable;
import java.util.Objects;

public class ReporteId implements Serializable {
    private String date;
    private String iso;

    public ReporteId() {
    }

    public ReporteId(String date, String iso) {
        this.date = date;
        this.iso = iso;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getIso() {
        return iso;
    }

    public void setIso(String iso) {
        this.iso = iso;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ReporteId)) return false;
        ReporteId that = (ReporteId) o;
        return Objects.equals(date, that.date) &&
                Objects.equals(iso, that.iso);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, iso);
    }
}
