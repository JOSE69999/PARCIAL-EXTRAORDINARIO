package com.miumgcovid.tarea.miumg.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.miumgcovid.tarea.miumg.models.ReporteAPI;

import java.util.List;

@Repository
public interface RepositorioReporte extends JpaRepository<ReporteAPI, String> {
    List<ReporteAPI> findByDateAndRegionIso(String date, String regionIso);
    List<ReporteAPI> findByIsoAndDate(String iso, String date);

    boolean existsByDateAndIso(String date, String iso);

}
