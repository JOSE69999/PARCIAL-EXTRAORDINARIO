package com.miumgcovid.tarea.miumg.controllers;

import com.miumgcovid.tarea.miumg.models.ProvinciaAPI;
import com.miumgcovid.tarea.miumg.models.RegionAPI;
import com.miumgcovid.tarea.miumg.models.ReporteAPI;
import com.miumgcovid.tarea.miumg.repositories.RepositorioHiloProceso;
import com.miumgcovid.tarea.miumg.repositories.RepositorioProvincia;
import com.miumgcovid.tarea.miumg.repositories.repositorioRegion;
import com.miumgcovid.tarea.miumg.repositories.RepositorioReporte;
import com.miumgcovid.tarea.miumg.services.ServicioPeticion;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class  MainController {

    @Autowired
    private ServicioPeticion servicioPeticion;

    @Autowired
    private repositorioRegion repositorioRegion;

    @Autowired
    private RepositorioProvincia repositorioProvincia;

    @Autowired
    private RepositorioReporte repositorioReporte;

    @Autowired
    private RepositorioHiloProceso hiloProceso;



    @GetMapping("/ejecutar")
    public ResponseEntity<String> ejecutarProceso() {
        hiloProceso.iniciarHilo();
        return ResponseEntity.ok("Proceso iniciado.");
    }

    // Endpoints para descargar y guardar
    @GetMapping("/regiones")
    public ResponseEntity<String> obtenerRegiones() {
        servicioPeticion.buscaRegiones();
        return ResponseEntity.ok("Regiones descargadas y guardadas.");
    }

    @GetMapping("/provinciaapi")
    public ResponseEntity<String> obtenerProvincias() {
        servicioPeticion.buscaProvincias();
        return ResponseEntity.ok("Provincias descargadas y guardadas.");
    }

    @GetMapping("/reportes")
    public ResponseEntity<String> obtenerReportes() {
        servicioPeticion.buscaReporte();
        return ResponseEntity.ok("Reportes descargados y guardados.");
    }

    // Endpoints para ver los datos guardados
    @GetMapping("/regiones/ver")
    public List<RegionAPI> verRegiones() {
        return repositorioRegion.findAll();
    }

    @GetMapping("/reportes/{iso}/{date}")
    public List<ReporteAPI> obtenerReportes(@PathVariable String iso, @PathVariable String date) {
        return servicioPeticion.obtenerReportesPorIsoYFecha(iso, date);
    }

    @GetMapping("/provinciaapi/ver")
    public List<ProvinciaAPI> verProvincias() {
        return repositorioProvincia.findAll();
    }

    @GetMapping("/reportes/ver")
    public List<ReporteAPI> verReportes() {
        return repositorioReporte.findAll();
    }

    // NUEVO: endpoint para obtener reportes agrupados por provincia (sin duplicados)
    @GetMapping("/reportes/agrupados")
    public List<ReporteAPI> obtenerReportesUnicosPorProvincia(
            @RequestParam String iso,
            @RequestParam String date
    ) {
        return servicioPeticion.obtenerReportesUnicosPorProvincia(iso, date);
    }
}
